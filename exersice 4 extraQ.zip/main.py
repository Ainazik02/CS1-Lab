cars=100
space_in_a_car = 4.0 #There is no difference between 4 and 4.0, the result will be the same.Because the python understands it itself even it is float (4 and a.0 both of them are real numbers)
drivers = 30
passengers = 90
cars_not_driven = cars - drivers
cars_driven = drivers
carpool_capacity = cars_driven * space_in_a_car
average_passengers_per_car1 =carpool_capacity/passengers 
#The error is occured is because of the mistake when typing "car_pool_capacity", istead "carpool_capacity". In python the strings must be the same as it written at the beginning, when giving them a value



print("We need to put about", average_passengers_per_car1, "in each car.")