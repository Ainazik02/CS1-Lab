#ex1
print("Hello, World!")

#ex2
a=3
b=2
print(a+b)
print(a-b)
print(a*b)

#ex3
a=4
b=3
print(a//b)
print(a/b)

#ex4
N=5
for i in range(N):
 print(i**2)

#ex5
n=24
if(n%2 !=0):
 print("Not Weird")
elif(n>=2 and n<=5 and n%2==0):
 print("Not Weird")
elif(n>=6 and n<=20 and n%2==0):
 print("Weird") 
elif(n>=20 and n%2==0):   
 print("Not Weird")
