x = "There are %d types of people." %10 #string inside the string
binary = "binary"
do_not = "don't"
y = "Those who know %s and those who %s." %(binary, do_not) #string inside the string2
print("\n")
print(x) #now we started to print string inside the string1
print(y)  #now we started to print string inside the string2
print("\n")
print("I said: %r" %x) #To be perfectly honest,I think this line is also string inside the string3
print("I also said: '%s'" %y) #string inside the string4
print("\n")
hilarious = "False"
joke_evaluation = "Isn't that joke so funny?!"
print("\n")
print(joke_evaluation +hilarious) #Here i just combined the strings1
print("\n")
w = "This is the left side of..."
e = "a string with a right side."
print("\n")
print(w + e) #Here i just combined the strings2, that is why it is now lons string )

